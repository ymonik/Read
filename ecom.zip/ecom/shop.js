document.addEventListener("DOMContentLoaded", function () {
    const bookshelf = document.getElementById("bookshelf");
    const main = document.querySelector("main");
    const header = document.querySelector("header");

    const booksData = [
        {
            "author": "	Chris Sanders",
            "country": "United States",
            "imageLink": "https://books.disney.com/content/uploads/2024/06/liloandstitch626-280x425.jpg",
            "language": "English",
            "link": "https://en.wikipedia.org/wiki/Lilo_%26_Stitch",
            "pages": 124,
            "title": "LILO & STITCH",
            "year": 2002,
            "price": 22.22
        },
        {
            "author": "Chinua Achebe",
            "country": "Nigeria",
            "imageLink": "images/things-fall-apart.jpg",
            "language": "English",
            "link": "https://en.wikipedia.org/wiki/Things_Fall_Apart\n",
            "pages": 209,
            "title": "Things Fall Apart",
            "year": 1958,
            "price": 20.99
        },
        {
            "author": " Burt Gillett ",
            "country": "United States",
            "imageLink": "https://upload.wikimedia.org/wikipedia/commons/thumb/b/bf/Mickey_Mouse_Color_Stock_Poster_%28Celebrity_Productions_era%2C_1928%29.jpg/220px-Mickey_Mouse_Color_Stock_Poster_%28Celebrity_Productions_era%2C_1928%29.jpg",
            "language": "English",
            "link": "https://en.wikipedia.org/wiki/Mickey_Mouse_(film_series)",
            "pages": 784,
            "title": "Mickey Mouse (film series)",
            "year": 1950,
            "price": 50.66
        },
        {
            "author": "	Hal Roach",
            "country": "United States",
            "imageLink": "https://upload.wikimedia.org/wikipedia/commons/thumb/3/31/Grandmas_Boy_Poster.jpg/220px-Grandmas_Boy_Poster.jpg",
            "language": "English",
            "link": "https://en.wikipedia.org/wiki/Grandma%27s_Boy_(1922_film)",
            "pages": 289,
            "title": "Grandma's Boy (1922 film)",
            "year": 1922,
            "price": 38.21
        },
        {
            "author": "Ron Clements",
            "country": "United States",
            "imageLink": "https://upload.wikimedia.org/wikipedia/en/8/81/The_Princess_and_the_Frog_poster.jpg",
            "language": "English",
            "link": "https://en.wikipedia.org/wiki/The_Princess_and_the_Frog",
            "pages": 160,
            "title": "The Princess and the Frog",
            "year": 2009,
            "price": 45.23
        },

        {
            "author": "Unknown",
            "country": "India Iran Iraq Egypt Tajikistan",
            "imageLink": "images/one-thousand-and-one-nights.jpg",
            "language": "Arabic",
            "link": "https://en.wikipedia.org/wiki/One_Thousand_and_One_Nights\n",
            "pages": 288,
            "title": "One Thousand and One Nights",
            "year": 1200,
            "price": 23.55
        },
        {
            "author": "Unknown",
            "country": "Iceland",
            "imageLink": "images/njals-saga.jpg",
            "language": "Old Norse",
            "link": "https://en.wikipedia.org/wiki/Nj%C3%A1ls_saga\n",
            "pages": 384,
            "title": "Nj\u00e1l's Saga",
            "year": 1350,
            "price": 72.26
        },
        {
            "author": "Jane Austen",
            "country": "United Kingdom",
            "imageLink": "images/pride-and-prejudice.jpg",
            "language": "English",
            "link": "https://en.wikipedia.org/wiki/Pride_and_Prejudice\n",
            "pages": 226,
            "title": "Pride and Prejudice",
            "year": 1813,
            "price": 60.12
        },
        {
            "author": "Honor\u00e9 de Balzac",
            "country": "France",
            "imageLink": "images/le-pere-goriot.jpg",
            "language": "French",
            "link": "https://en.wikipedia.org/wiki/Le_P%C3%A8re_Goriot\n",
            "pages": 443,
            "title": "Le P\u00e8re Goriot",
            "year": 1835,
            "price": 99.99
        },
        {
            "author": "Samuel Beckett",
            "country": "Republic of Ireland",
            "imageLink": "images/molloy-malone-dies-the-unnamable.jpg",
            "language": "French, English",
            "link": "https://en.wikipedia.org/wiki/Molloy_(novel)\n",
            "pages": 256,
            "title": "Molloy, Malone Dies, The Unnamable, the trilogy",
            "year": 1952,
            "price": 76.35
        },
        {
            "author": "Jessie Willcox Smith",
            "country": "Italy",
            "imageLink": "https://upload.wikimedia.org/wikipedia/commons/thumb/c/ca/Fairy_Tales_%28Boston_Public_Library%29.jpg/220px-Fairy_Tales_%28Boston_Public_Library%29.jpg",
            "language": "Italian",
            "link": "https://en.wikipedia.org/wiki/Children%27s_literature",
            "pages": 1024,
            "title": "The Decameron",
            "year": 1351,
            "price": 35.74
        },
        {
            "author": "Jorge Luis Borges",
            "country": "Argentina",
            "imageLink": "images/ficciones.jpg",
            "language": "Spanish",
            "link": "https://en.wikipedia.org/wiki/Ficciones\n",
            "pages": 224,
            "title": "Ficciones",
            "year": 1965,
            "price": 32.74
        },
        {
            "author": "Emily Bront\u00eb",
            "country": "United Kingdom",
            "imageLink": "images/wuthering-heights.jpg",
            "language": "English",
            "link": "https://en.wikipedia.org/wiki/Wuthering_Heights\n",
            "pages": 342,
            "title": "Wuthering Heights",
            "year": 1847,
            "price": 25.55
        },
        {
            "author": "Albert Camus",
            "country": "Algeria, French Empire",
            "imageLink": "images/l-etranger.jpg",
            "language": "French",
            "link": "https://en.wikipedia.org/wiki/The_Stranger_(novel)\n",
            "pages": 185,
            "title": "The Stranger",
            "year": 1942,
            "price": 88.21
        },
        {
            "author": "Paul Celan",
            "country": "Romania, France",
            "imageLink": "images/poems-paul-celan.jpg",
            "language": "German",
            "link": "\n",
            "pages": 320,
            "title": "Poems",
            "year": 1952,
            "price": 54.68
        },
        {
            "author": "Louis-Ferdinand C\u00e9line",
            "country": "France",
            "imageLink": "https://upload.wikimedia.org/wikipedia/commons/thumb/4/43/Doctor_Who_Logo_2023.svg/220px-Doctor_Who_Logo_2023.svg.png",
            "language": "French",
            "link": "https://en.wikipedia.org/wiki/Doctor_Who\n",
            "pages": 505,
            "title": "Journey to the End of the Night",
            "year": 1932,
            "price": 62.66
        },
        {
            "author": "Jeffry Scot",
            "country": "France",
            "imageLink":"https://upload.wikimedia.org/wikipedia/en/thumb/b/b6/Little_Krishna_Poster.jpg/220px-Little_Krishna_Poster.jpg",
            "language": "English",
            "link": "https://en.wikipedia.org/wiki/Little_Krishna\n",
            "pages": 505,
            "title": "Little Krishna",
            "year": 1932,
            "price": 62.66
        },
        {
            "author": "James Bateman;",
            "country": "France",
            "imageLink": "https://upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Henry_Gibson_1969_%28cropped_version%29.JPG/220px-Henry_Gibson_1969_%28cropped_version%29.JPG",
            "language": "French",
            "link": "https://en.wikipedia.org/wiki/Henry_Gibson",
            "pages": 443,
            "title": "Henry Gibson ",
            "year": 1835,
            "price": 99.99
        },
        {
            "author": "Serge Danot;",
            "country": "France",
            "imageLink": "https://c8.alamy.com/comp/2JD8FK6/florencedougaldylanzebedeeermintrudebrianzeebad-the-magic-roundabout-2005-2JD8FK6.jpg",
            "language": "French",
            "link": "https://en.wikipedia.org/wiki/The_Magic_Roundabout",
            "pages": 443,
            "title": "The Magic Round About",
            "year": 1835,
            "price": 99.99
        },
        
        
    ];
    const colors = ["#FF6633", "#FFB399", "#FF33FF", "#FFFF99", "#00B3E6",
        "#E6B333", "#3366E6", "#999966", "#99FF99", "#B34D4D",
        "#80B300", "#809900", "#E6B3B3", "#6680B3", "#66991A",];

    let cart = [];
    let totalCost = 0;

    function showBooks() {
        bookshelf.innerHTML = "";
        booksData.forEach((book, index) => {
            const bookElement = document.createElement("div");
            bookElement.classList.add("book");
            bookElement.innerHTML = `
        <img src="${book.imageLink}" alt="${book.title}">
        <h4>${book.title}</h4>
        <p class="price">Price: $${book.price}</p>
        <div class="details">
          <p>By ${book.author}</p>
          <p>Year:${book.year}</p>
          <p>Language:${book.language}</p>
          <p>Country:${book.country}</p>
          <p>Pages:${book.pages}</p>
          <a href=${book.link}>Link</a>
          <br>
          <br>
          <button class="add-to-cart">Add to Cart</button>
        </div>
        `;
            const style = document.createElement("style");
            style.textContent = `.book:nth-child(${index + 1}):hover .details { background-color: ${colors[index % colors.length]}; }`;
            document.head.appendChild(style);

            const addToCartButton = bookElement.querySelector(".add-to-cart");
            addToCartButton.addEventListener("click", () => {
                cart.push(book);
                totalCost += parseFloat(book.price);
                updateCartDisplay();
            });
            bookshelf.appendChild(bookElement);
        });
    }
    showBooks();

    function updateCartDisplay() {
        const cartItemsElement = document.getElementById("cart-items");
        const totalPriceElement = document.getElementById("total-price");
        cartItemsElement.innerHTML = "";
        cart.forEach((book) => {
            const cartItemElement = document.createElement("li");
            cartItemElement.innerHTML = `
                <div>
                    <img src="${book.imageLink}" alt="${book.title}" width="150px">
                    <h6>${book.title}</h6>
                    <p>Price: $${book.price}</p>
                </div>
            `;
            cartItemsElement.appendChild(cartItemElement);
        });
    
        totalPriceElement.textContent = `$${totalCost.toFixed(2)}`;
        saveCartToStorage();
    }

    const cartLink = document.getElementById("cartLink");
    cartLink.addEventListener("click", (event) => {
        event.preventDefault();
        main.innerHTML = "";
        const cartContainer = document.createElement("div");
        cartContainer.id = "cart";
        cartContainer.innerHTML = `
    <h2>Cart</h2>
    <ul id="cart-items"></ul>
    <p>Total: <span id="total-price">$0</span></p>
  `;
        main.appendChild(cartContainer);
        updateCartDisplay();
    });

    booksLink.addEventListener("click", function (event) {
        event.preventDefault();
        main.innerHTML = `
        <div id="bookshelf">
            <a href="ebook.html">Go to Home Page</a>
        </div>
    `;
        main.appendChild(bookshelf);
        header.style.display = "none";
    });
    
});
document.addEventListener('DOMContentLoaded', function() {
    const scrollContainer = document.querySelector('.scroll-container');
    let isDown = false;
    let startX;
    let scrollLeft;
    
    scrollContainer.addEventListener('mousedown', (e) => {
        isDown = true;
        scrollContainer.classList.add('active');
        startX = e.pageX - scrollContainer.offsetLeft;
        scrollLeft = scrollContainer.scrollLeft;
    });
    
    scrollContainer.addEventListener('mouseleave', () => {
        isDown = false;
        scrollContainer.classList.remove('active');
    });
    
    scrollContainer.addEventListener('mouseup', () => {
        isDown = false;
        scrollContainer.classList.remove('active');
    });
    
    scrollContainer.addEventListener('mousemove', (e) => {
        if (!isDown) return;
        e.preventDefault();
        const x = e.pageX - scrollContainer.offsetLeft;
        const walk = (x - startX) * 3; //scroll-fast
        scrollContainer.scrollLeft = scrollLeft - walk;
    });
    });
    document.addEventListener('DOMContentLoaded', function() {
        const subscribeForm = document.getElementById('subscribe-form');
        subscribeForm.addEventListener('submit', function(event) {
            event.preventDefault();
            const email = subscribeForm.querySelector('input[type="email"]').value;
            alert(`Thank you for subscribing with ${email}!`);
            subscribeForm.reset();
        });
    });
    function updateCartDisplay() {
        const cartItemsElement = document.getElementById("cart-items");
        const totalPriceElement = document.getElementById("total-price");
        cartItemsElement.innerHTML = "";
        cart.forEach((book, index) => {
          const cartItemElement = document.createElement("li");
          cartItemElement.innerHTML = `
            <div>
              <img src="${book.imageLink}" alt="${book.title}" width="150px">
              <h6>${book.title}</h6>
              <p>Price: $${book.price}</p>
              <button class="remove-from-cart" data-index="${index}">Remove</button>
            </div>
          `;
          cartItemElement.querySelector(".remove-from-cart").addEventListener("click", () => {
            cart.splice(index, 1); // Remove item from cart array
            totalCost -= parseFloat(book.price); // Update total cost
            updateCartDisplay(); // Update cart display
          });
          cartItemsElement.appendChild(cartItemElement);
        });
      
        totalPriceElement.textContent = `$${totalCost.toFixed(2)}`;
        saveCartToStorage();
      }
      

